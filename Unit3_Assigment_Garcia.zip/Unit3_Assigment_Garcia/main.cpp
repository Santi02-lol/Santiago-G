/*
Santiago garcia
9/4/2023
Teacher: Dr. Tyson Mcmillan
Text editor: Replit
The purpose of this program is to gather
the user input to set arithmetic operations
and use if statement when the user inputs
a zero in division.
*/
#include <iostream>
using namespace std;

int main() {
  double number1, number2, addition, subtraction;
  double multiplication, division;
  int number3,number4,modulus;
  //INPUT
  cout << "Enter number1 here: ";
  cin >> number1;
  cout << "Enter number2 here: ";
  cin >> number2;
  cout << "Enter number3 here: ";
  cin >> number3;
  cout << "Enter number4 here: ";
  cin >> number4;
  //Process / output
   addition = (number1+number2);
  cout << "The additional total of " << number1 << " plus ";
  cout << number2 << " is: " << addition << endl;

  subtraction = (number1-number2);
  cout << "The subtracted total of " << number1 << " minus ";
  cout << number2 << " is: " << subtraction << endl;

  multiplication = (number1*number2);
  cout << "The multiplied total of " << number1 << " times ";
  cout << number2 << " is: " << multiplication << endl;
  // if the user does not input zero in number2, then the program would display with no issues
  if (number2 == 0)
  {
    cout << "// ERROR // Dividing a number over zero would not work in division." << endl;
    cout << "Input another value in number2 other than zero." << endl;
  }
  else
  {
    division = (number1/number2);
    cout << "The divided total of " << number1 << " divided by ";
    cout << number2 << " is: " << division << endl;
  }
  // if the user does not input zero in number4, then the program would display with no issues
if (number4 ==0)
{
  cout << "// ERROR // dividing a number over zero would not work in modulus.\n";
  cout << "input another value in number4 other than zero.\n";
}
else
{
  modulus = (number3%number4);
  cout << "The modulus remainder number of " << number3 << " divided by ";
  cout << number4 << " is: " << modulus << endl;
}
 
  return 0;
}